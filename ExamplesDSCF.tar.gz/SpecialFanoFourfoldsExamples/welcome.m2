
-*
# Useful commands for maintaining the archive.

# Rename files from dscf_n-i.dat to dscf_i.dat
for f in *n-*; do mv -- "$f" "${f/n-/}"; done

# Compare the old and new directories
git diff --no-index --no-color -U0 old new > diff.txt

# Show the differences with colors in the terminal
git diff --no-index --color old new

# Create the archive
tar -czf examples.tar.gz SpecialFanoFourfoldsExamples

# Copy files to the local Macaulay2 archive directory
cp * /home/debian/.Macaulay2/SpecialFanoFourfoldsExamples/
cp Tables.m2 /home/debian/.Macaulay2/SpecialFanoFourfoldsExamples/
cp welcome.m2 /home/debian/.Macaulay2/SpecialFanoFourfoldsExamples/
*-

F := applicationDirectory()|"SpecialFanoFourfoldsExamples/Tables.m2";
if not fileExists F then error "missing file Tables.m2 in SpecialFanoFourfoldsExamples";
needsPackage("Tables",FileName=>F);

<<///
-- 115 examples of doubly special cubic fourfolds available.
-- Last update: October 7, 2026.
-- Load the i-th example with example i.
-- Generate LaTeX tables of all examples with tables().
-- Use describe(example i) for a description of the example.
-- Use constructionInfo(example i) for additional information.
///;
