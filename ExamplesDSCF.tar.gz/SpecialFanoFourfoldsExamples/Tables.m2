
newPackage(
    "Tables",
    Version => "1.0",
    Date => "October 7, 2026",
    Headline => "Generate LaTeX tables for the examples contained in the archive.",
    PackageExports => {"SpecialFanoFourfolds"}
);

export {"tables", "constructionInfo", "tabK3", "tabAll"};

debug SpecialFanoFourfolds;

TableExamplesWithK3 = {};
TableExamplesAll = {};

tabK3 = n -> (
    if not instance(n,ZZ) then error "expected an integer";
    buildTablesIfNecessary();
    if n < 1 or n > #TableExamplesWithK3 then error("expected an integer between 1 and " | toString(#TableExamplesWithK3));
    TableExamplesWithK3_(n-1)
);

tabAll = n -> (
    if not instance(n,ZZ) then error "expected an integer";
    buildTablesIfNecessary();
    if n < 1 or n > #TableExamplesAll then error("expected an integer between 1 and " | toString(#TableExamplesAll));
    TableExamplesAll_(n-1)
);

texTables2 = method(Options => {Verbose => true, KeepFiles => false, "OpenPDF" => true});

texTables2 Nothing := o -> nu -> (
    L := for i from 1 to numberOfExamplesInArchive() list example(i,0);
    if o.Verbose then << "-- building LaTeX tables with texTables()..." << endl;
    I := (L,Verbose=>o.Verbose,KeepFiles=>o.KeepFiles,"OpenPDF"=>o#"OpenPDF","NoetherLefschetzLocus"=>hassettDivisorsIntersectionTex,"ExampleID"=>archiveExampleID);
    TableExamplesAll = texTableRaw append(I,"IncludeK3Info"=>false);
    TableExamplesWithK3 = texTableRaw append(I,"IncludeK3Info"=>true);
    apply(TableExamplesWithK3,sanityCheckDSCFOnFourfold);
    if fileExists "tableAll.pdf" and fileExists "tableK3.pdf" then << "-- use tabAll(i) and tabK3(i) to get the i-th example from the corresponding table" << endl;
);

tables = () -> texTables2(null);

buildTablesIfNecessary = () -> (
    if #TableExamplesAll === numberOfExamplesInArchive() then return;
    texTables2(null,"OpenPDF"=>false);
);

ThirdHassettDiscriminant := {
(((2,0,0,0,0),(1,0,0,0,0)), 14),
(((5,8,2,0,0),(3,7,2,0,0)), 14),
(((4,8,0,0,0),(3,8,0,0,0)), 12),
(((5,10,1,0,0),(3,8,1,0,0)), 18),
(((5,7,2,0,0),(3,6,2,0,0)), 20),
(((6,5,5,0,0),(3,5,4,0,0)), 24),
(((4,7,0,0,0),(3,7,0,0,0)), 20),
(((5,6,2,0,0),(3,5,2,0,0)), 30),
(((4,6,0,0,0),(3,6,0,0,0)), 32),
(((6,0,7,0,0),(3,0,7,0,0)), 12),
(((7,5,6,1,0),(3,2,6,1,0)), 12),
(((7,2,7,1,0),(3,0,7,1,0)), 14),
(((6,4,6,0,0),(3,3,6,0,0)), 12),
(((6,3,6,0,0),(3,2,6,0,0)), 14),
(((6,2,6,0,0),(3,1,6,0,0)), 20),
(((5,8,0,1,0),(3,8,0,1,0)), 12),
(((6,1,6,0,0),(3,0,6,0,0)), 30),
(((6,6,5,0,0),(3,4,5,0,0)), 14),
(((6,5,5,0,0),(3,3,5,0,0)), 18),
(((7,3,9,0,0),(3,0,9,0,0)), 14),
(((7,3,7,1,0),(3,1,7,1,0)), 14),
(((7,2,9,0,0),(3,1,8,0,0)), 18),
(((5,7,0,1,0),(3,7,0,1,0)), 20),
(((7,2,7,1,0),(3,2,6,1,0)), 20),
(((7,1,7,1,0),(3,1,6,1,0)), 24),
(((7,0,10,0,0),(3,0,9,0,0)), 20),
(((5,6,0,1,0),(3,6,0,1,0)), 32)};

hassettDivisorsIntersectionTex = X -> (
    d := discriminant X;
    Cd1Cd2 := /// $\mathcal C_{/// | (toString d) | "}";
    if d != 8 then Cd1Cd2 = Cd1Cd2 | ///\cap \mathcal C_8 ///;
    n := position(ThirdHassettDiscriminant, i -> first i == take((surface X).cache#"ConstructionParameters",2));
    if n === null then (
        Cd1Cd2 = Cd1Cd2 | "$ ";
    ) else (
        Cd1Cd2 = Cd1Cd2 | /// \cap \mathcal C_{/// | (toString last ThirdHassettDiscriminant_n) | "} $ ";
    );
    Cd1Cd2
);

sanityCheckDSCFOnFourfold = method();
sanityCheckDSCFOnFourfold DoublySpecialCubicFourfold := X -> (
    if not hasRationalSection X then return;
    i := archiveExampleIDold X;
    assert(i =!= null);
    if computationStatus X < 2 then return;
    mu := fanoMapDSCF(X,Verbose=>true);
    W := target mu;
    (L,C) := exceptionalCurves(X,Verbose=>false);
    U := ambientVariety L;
    if knownDataForRecognizedDSCF i === (degreeOfDefiningForms mu, dim W, degree W, sectionalGenus W, degrees W, dim U, degree U, sectionalGenus U, euler hilbertPolynomial U, degrees U, dim L, degree L, dim C, degree C) then (
        -- << "-- sanity checks passed for example ID: " << i << endl;
    ) else (
        error("sanity checks failed for DSCF example ID: "|(toString i));
    );
);

archiveExampleIDold = X -> (
    if not instance(X,DoublySpecialCubicFourfold) then return;
    if substring(recognizeDSCF X,0,8) =!= "DSCF-V1-" then return;
    j := value substring(recognizeDSCF X,8);
    if instance(j,ZZ) and j >= 1 and j <= 40 then return j;
);

archiveExampleID = X -> (
    i := exampleNumberInArchive X;
    if i >= 1 and i <= 40 then assert(i === archiveExampleIDold X);
    i
);

exampleNumberInArchive = method();
exampleNumberInArchive DoublySpecialCubicFourfold := X -> exampleNumberInArchive take((surface X).cache#"ConstructionParameters",2);
exampleNumberInArchive (Sequence,Sequence) := (p1,p2) -> (
    assert(#p1 == 5 and #p2 == 5);
    p := (p1,p2);
    assert(uniform splice p and instance(first splice p,ZZ));
    L := for i from 1 to numberOfExamplesInArchive() list example(i,0);
    sL := apply(L, X -> take((surface X).cache#"ConstructionParameters",2));
    n := position(sL, i -> i == p);
    -- if n === null then return null;
    if n === null then error "example not found";
    N := n + 1;
    assert(take((surface example(N,0)).cache#"ConstructionParameters",2) === p);
    N
);

numberOfExamplesInArchive = memoize(() -> (
    << "-- loading list of examples imported with store \"...\"" << endl;
    for i from 1 do (
        try example(i,0) else (
            << "-- obtained " << i-1 << " examples" << endl;
            return(i-1);
        );
    );
));

constructionInfo = method();
constructionInfo DoublySpecialCubicFourfold := Y -> (
    buildTablesIfNecessary();
    << describe Y << endl << endl;
    << "-- Commands to retrieve this example:" << endl;
    << "-- example " << (exampleNumberInArchive Y) << endl;
    p := take((surface Y).cache#"ConstructionParameters",2);
    jK3 := position(apply(TableExamplesWithK3, X -> take((surface X).cache#"ConstructionParameters",2)), i -> i == p);
    jAll := position(apply(TableExamplesAll, X -> take((surface X).cache#"ConstructionParameters",2)), i -> i == p);
    if jAll =!= null then << "-- tabAll " << jAll + 1 << endl;
    if jK3 =!= null then << "-- tabK3 " << jK3 + 1 << endl;
);
