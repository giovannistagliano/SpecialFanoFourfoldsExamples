<< ///
-- Welcome to the SpecialFanoFourfolds examples archive.
-- Use example(...) to load examples and texTables(n) to generate summary tables.
-- Last update: October 12, 2026./// << endl;
