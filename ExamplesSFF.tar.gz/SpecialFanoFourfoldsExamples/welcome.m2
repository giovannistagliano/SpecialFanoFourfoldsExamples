
-*
# Useful commands for maintaining the archive.

# Rename files from dscf_n-i.dat to dscf_i.dat
for f in *n-*; do mv -- "$f" "${f/n-/}"; done

# Compare the old and new directories
git diff --no-index --no-color -U0 old new > diff.txt

# Show the differences with colors in the terminal
git diff --no-index --color old new

# Create the archive
tar -czf ExamplesSFF.tar.gz SpecialFanoFourfoldsExamples

# Extract the archive
tar -xzf ExamplesSFF.tar.gz

# Copy files to the local Macaulay2 archive directory
cp * /home/debian/.Macaulay2/SpecialFanoFourfoldsExamples/
cp welcome.m2 /home/debian/.Macaulay2/SpecialFanoFourfoldsExamples/
*-

TablesCode := ///
tablesInternal := () -> (
    (TableExamplesAll,TableExamplesWithK3) := texTables(0,OpenPDF=>true);
    if not(fileExists "tableAll.pdf" and fileExists "tableK3.pdf") then error "failed to generate one or more PDF tables";
    getInfo := X -> (
        << describe X << endl << endl;
        << "-- Commands to retrieve this example:" << endl;
        << "-- example(" << (if X.cache#?"exampleNameInArchive" then X.cache#"exampleNameInArchive" | ",0)" else " - ") << endl;
        p := take((surface X).cache#"ConstructionParameters",2);
        jK3 := position(apply(TableExamplesWithK3, Y -> take((surface Y).cache#"ConstructionParameters",2)), i -> i == p);
        jAll := position(apply(TableExamplesAll, Y -> take((surface Y).cache#"ConstructionParameters",2)), i -> i == p);
        if jAll =!= null then << "-- tabAll " << jAll + 1 << endl;
        if jK3 =!= null then << "-- tabK3 " << jK3 + 1 << endl;
    );
    tabK3 := n -> (
        if (not instance(n,ZZ)) or n < 1 or n > #TableExamplesWithK3 then (
            << ("expected an integer between 1 and " | toString(#TableExamplesWithK3)) << endl;
            return;
        );
        TableExamplesWithK3_(n-1)
    );
    tabAll := n -> (
        if (not instance(n,ZZ)) or n < 1 or n > #TableExamplesAll then (
            << ("expected an integer between 1 and " | toString(#TableExamplesAll)) << endl;
            return;
        );
        TableExamplesAll_(n-1)
    );
    << "-- use tabAll(i) and tabK3(i) to get the i-th example from the corresponding table" << endl;
    << "-- use getInfo(...) for retrieval commands and construction data" << endl;
    (getInfo,tabK3,tabAll)
);
(getInfo,tabK3,tabAll) = tablesInternal();
///;
tables = () -> value TablesCode;

<< ///
-- examples available in the local archive, including 115 doubly special cubic fourfolds.
-- Last update: October 10, 2026.
-- Load an example with example(i,n), where n specifies the example type.
-- Generate LaTeX tables with texTables(n).
-- tables() provides additional utilities based on texTables(0)./// << endl;
