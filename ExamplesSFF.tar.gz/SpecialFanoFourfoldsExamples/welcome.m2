
<< "-- Welcome to the SpecialFanoFourfolds examples archive." << endl;
<< "-- Last update: October 14, 2026." << endl;
